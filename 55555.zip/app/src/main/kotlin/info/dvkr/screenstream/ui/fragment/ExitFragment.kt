package info.dvkr.screenstream.ui.fragment

import androidx.fragment.app.Fragment

class ExitFragment : Fragment()